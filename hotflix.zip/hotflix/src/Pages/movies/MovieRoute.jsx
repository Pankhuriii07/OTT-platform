import React from 'react'


const MovieRoute = () => {
  return (
    <div>
      <h1 style={{color:"white",marginLeft:"125px"}}>MovieRoute</h1>
    </div>
  )
}

export default MovieRoute
